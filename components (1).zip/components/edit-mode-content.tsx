"use client"

import * as React from "react"
import { PlusIcon, PencilIcon, Trash2Icon, CheckIcon, XIcon, ServerIcon, PackageIcon, UploadIcon, LinkIcon } from "lucide-react"
import { refillData } from "@/lib/refill-data"
import type { RefillItem } from "@/components/refill-table"
import {
  Table,
  TableBody,
  TableCell,
  TableHead,
  TableHeader,
  TableRow,
} from "@/components/ui/table"
import { Button } from "@/components/ui/button"
import { getMachines, saveMachines, type Machine } from "@/lib/machine-store"
import { ImageLightbox } from "@/components/image-lightbox"

type Tab = "products" | "machines"
type EditableItem = RefillItem & { machineId: string }

function buildInitialData(): EditableItem[] {
  return Object.entries(refillData).flatMap(([machineId, items]) =>
    items.map((item) => ({ ...item, machineId }))
  )
}

const inputCls =
  "w-full rounded-md border bg-background px-2 py-1 text-xs focus:outline-none focus:ring-1 focus:ring-ring"

// ─── Product edit row ───────────────────────────────────────────────────────

interface EditRowProps {
  item: EditableItem
  machines: Machine[]
  onSave: (updated: EditableItem) => void
  onCancel: () => void
}

function EditRow({ item, machines, onSave, onCancel }: EditRowProps) {
  const [draft, setDraft] = React.useState(item)
  const [imageMode, setImageMode] = React.useState<"url" | "upload">("url")
  const fileRef = React.useRef<HTMLInputElement>(null)

  function set<K extends keyof EditableItem>(key: K, val: EditableItem[K]) {
    setDraft((prev) => ({ ...prev, [key]: val }))
  }

  function handleFile(e: React.ChangeEvent<HTMLInputElement>) {
    const file = e.target.files?.[0]
    if (!file) return
    const reader = new FileReader()
    reader.onload = () => set("image", reader.result as string)
    reader.readAsDataURL(file)
  }

  return (
    <TableRow className="bg-accent/20">
      <TableCell className="py-1.5 text-center">
        <input className={inputCls} value={draft.slot} onChange={(e) => set("slot", e.target.value)} />
      </TableCell>
      <TableCell className="py-1.5 text-center">
        <input className={inputCls} value={draft.productCode} onChange={(e) => set("productCode", e.target.value)} />
      </TableCell>
      <TableCell className="py-1.5">
        <div className="flex flex-col gap-1.5">
          <input className={inputCls} value={draft.productName} onChange={(e) => set("productName", e.target.value)} placeholder="Product name" />
          <div className="flex items-center gap-1">
            {draft.image && (
              <div className="relative h-7 w-7 rounded overflow-hidden border bg-muted shrink-0">
                <img src={draft.image} alt="" className="h-full w-full object-cover" />
              </div>
            )}
            <div className="flex gap-1 flex-1">
              <button
                type="button"
                onClick={() => setImageMode("url")}
                className={`flex items-center gap-1 rounded px-1.5 py-1 text-[10px] border transition-colors ${imageMode === "url" ? "bg-foreground text-background border-foreground" : "text-muted-foreground border-border hover:text-foreground"}`}
              >
                <LinkIcon className="size-3" /> URL
              </button>
              <button
                type="button"
                onClick={() => { setImageMode("upload"); fileRef.current?.click() }}
                className={`flex items-center gap-1 rounded px-1.5 py-1 text-[10px] border transition-colors ${imageMode === "upload" ? "bg-foreground text-background border-foreground" : "text-muted-foreground border-border hover:text-foreground"}`}
              >
                <UploadIcon className="size-3" /> Upload
              </button>
              <input ref={fileRef} type="file" accept="image/*" className="hidden" onChange={handleFile} />
            </div>
          </div>
          {imageMode === "url" && (
            <input
              className={inputCls}
              value={draft.image}
              onChange={(e) => set("image", e.target.value)}
              placeholder="https://..."
            />
          )}
        </div>
      </TableCell>
      <TableCell className="py-1.5 text-center">
        <input
          type="number" min={0} className={inputCls} value={draft.maxCapacity}
          onChange={(e) => set("maxCapacity", Math.max(0, parseInt(e.target.value) || 0))}
        />
      </TableCell>
      <TableCell className="py-1.5 text-center">
        <select className={inputCls} value={draft.machineId} onChange={(e) => set("machineId", e.target.value)}>
          {machines.map((m) => (
            <option key={m.value} value={m.value}>{m.value}</option>
          ))}
        </select>
      </TableCell>
      <TableCell className="py-1.5">
        <div className="flex justify-center gap-1">
          <button onClick={() => onSave(draft)} className="rounded p-1 hover:bg-emerald-100 dark:hover:bg-emerald-900 text-emerald-600">
            <CheckIcon className="size-3.5" />
          </button>
          <button onClick={onCancel} className="rounded p-1 hover:bg-muted text-muted-foreground">
            <XIcon className="size-3.5" />
          </button>
        </div>
      </TableCell>
    </TableRow>
  )
}

// ─── Machine edit row ───────────────────────────────────────────────────────

interface MachineEditRowProps {
  machine: Machine
  onSave: (updated: Machine) => void
  onCancel: () => void
}

function MachineEditRow({ machine, onSave, onCancel }: MachineEditRowProps) {
  const [draft, setDraft] = React.useState(machine)
  return (
    <TableRow className="bg-accent/20">
      <TableCell className="py-1.5">
        <input
          className={inputCls} value={draft.value}
          onChange={(e) => setDraft((p) => ({ ...p, value: e.target.value.toUpperCase() }))}
          placeholder="M0001"
        />
      </TableCell>
      <TableCell className="py-1.5">
        <input
          className={inputCls} value={draft.label}
          onChange={(e) => setDraft((p) => ({ ...p, label: e.target.value }))}
          placeholder="M0001 — Location name"
        />
      </TableCell>
      <TableCell className="py-1.5">
        <div className="flex justify-center gap-1">
          <button onClick={() => onSave(draft)} className="rounded p-1 hover:bg-emerald-100 dark:hover:bg-emerald-900 text-emerald-600">
            <CheckIcon className="size-3.5" />
          </button>
          <button onClick={onCancel} className="rounded p-1 hover:bg-muted text-muted-foreground">
            <XIcon className="size-3.5" />
          </button>
        </div>
      </TableCell>
    </TableRow>
  )
}

// ─── Main component ─────────────────────────────────────────────────────────

export function EditModeContent() {
  const [tab, setTab] = React.useState<Tab>("products")

  // machines state
  const [machines, setMachines] = React.useState<Machine[]>([])
  React.useEffect(() => { setMachines(getMachines()) }, [])

  const persistMachines = (updated: Machine[]) => {
    setMachines(updated)
    saveMachines(updated)
  }

  // product state
  const [items, setItems] = React.useState<EditableItem[]>(buildInitialData)
  const [editingKey, setEditingKey] = React.useState<string | null>(null)
  const [addingNew, setAddingNew] = React.useState(false)
  const [filterMachine, setFilterMachine] = React.useState<string>("all")
  const [newItem, setNewItem] = React.useState<EditableItem>(() => ({
    slot: "", productCode: "", productName: "", image: "",
    stockIn: 0, overflow: 0, stockOut: 0, currentInventory: 0, maxCapacity: 10,
    machineId: getMachines()[0]?.value ?? "",
  }))

  const filteredItems = filterMachine === "all" ? items : items.filter((it) => it.machineId === filterMachine)

  // machine state
  const [editingMachineId, setEditingMachineId] = React.useState<string | null>(null)
  const [addingMachine, setAddingMachine] = React.useState(false)
  const [newMachine, setNewMachine] = React.useState<Machine>({ value: "", label: "" })

  function rowKey(item: EditableItem) { return `${item.machineId}-${item.slot}` }

  function handleSaveProduct(updated: EditableItem) {
    setItems((prev) => prev.map((it) => (rowKey(it) === editingKey ? updated : it)))
    setEditingKey(null)
  }
  function handleDeleteProduct(key: string) { setItems((prev) => prev.filter((it) => rowKey(it) !== key)) }
  function handleAddProduct(draft: EditableItem) { setItems((prev) => [...prev, draft]); setAddingNew(false) }

  function handleSaveMachine(updated: Machine) {
    persistMachines(machines.map((m) => (m.value === editingMachineId ? updated : m)))
    setEditingMachineId(null)
  }
  function handleDeleteMachine(value: string) { persistMachines(machines.filter((m) => m.value !== value)) }
  function handleAddMachine(draft: Machine) {
    if (!draft.value.trim()) return
    persistMachines([...machines, { value: draft.value.trim().toUpperCase(), label: draft.label.trim() || draft.value.trim().toUpperCase() }])
    setAddingMachine(false)
    setNewMachine({ value: "", label: "" })
  }

  return (
    <div className="flex flex-col gap-4">
      {/* Tab toggle */}
      <div className="flex items-center gap-1 rounded-lg border bg-muted/40 p-1 w-fit">
        <button
          onClick={() => setTab("products")}
          className={`flex items-center gap-1.5 rounded-md px-3 py-1.5 text-xs font-medium transition-colors ${
            tab === "products" ? "bg-background shadow-sm text-foreground" : "text-muted-foreground hover:text-foreground"
          }`}
        >
          <PackageIcon className="size-3.5" />
          Products
        </button>
        <button
          onClick={() => setTab("machines")}
          className={`flex items-center gap-1.5 rounded-md px-3 py-1.5 text-xs font-medium transition-colors ${
            tab === "machines" ? "bg-background shadow-sm text-foreground" : "text-muted-foreground hover:text-foreground"
          }`}
        >
          <ServerIcon className="size-3.5" />
          Machines
        </button>
      </div>

      {/* ── PRODUCTS TAB ── */}
      {tab === "products" && (
        <>
          <div className="flex items-center justify-between gap-3">
            <select
              value={filterMachine}
              onChange={(e) => setFilterMachine(e.target.value)}
              className="h-8 rounded-lg border bg-background px-2.5 text-xs font-medium focus:outline-none focus:ring-1 focus:ring-ring text-foreground"
            >
              <option value="all">All machines ({items.length})</option>
              {machines.map((m) => {
                const count = items.filter((it) => it.machineId === m.value).length
                return (
                  <option key={m.value} value={m.value}>
                    {m.value} — {m.label.replace(`${m.value} — `, "")} ({count})
                  </option>
                )
              })}
            </select>
            <Button size="sm" className="gap-1.5" onClick={() => { setAddingNew(true); setEditingKey(null) }}>
              <PlusIcon className="size-3.5" />
              Add Product
            </Button>
          </div>

          <div className="rounded-xl border bg-card overflow-hidden text-xs">
            <Table className="text-xs">
              <TableHeader>
                <TableRow className="hover:bg-transparent">
                  {["Slot", "Code", "Product Name", "Max", "Machine", "Actions"].map((h, i) => (
                    <TableHead key={i} className="text-center text-[11px] font-semibold tracking-wide py-2">{h}</TableHead>
                  ))}
                </TableRow>
              </TableHeader>
              <TableBody>
                {addingNew && (
                  <EditRow
                    item={newItem} machines={machines}
                    onSave={handleAddProduct}
                    onCancel={() => setAddingNew(false)}
                  />
                )}
                {filteredItems.map((item) => {
                  const key = rowKey(item)
                  if (editingKey === key) {
                    return (
                      <EditRow key={key} item={item} machines={machines}
                        onSave={handleSaveProduct} onCancel={() => setEditingKey(null)} />
                    )
                  }
                  return (
                    <TableRow key={key} className="h-10">
                      <TableCell className="text-center py-1.5">
                        <span className="font-mono font-bold tracking-wider">{item.slot}</span>
                      </TableCell>
                      <TableCell className="text-center py-1.5 text-muted-foreground">{item.productCode}</TableCell>
                      <TableCell className="py-1.5">
                        <div className="flex items-center gap-2">
                          {item.image && (
                            <ImageLightbox src={item.image} alt={item.productName}>
                              <div className="h-7 w-7 rounded-md overflow-hidden border bg-muted shrink-0">
                                <img src={item.image} alt={item.productName} className="h-full w-full object-cover" />
                              </div>
                            </ImageLightbox>
                          )}
                          <span className="font-medium truncate max-w-[160px]">{item.productName}</span>
                        </div>
                      </TableCell>
                      <TableCell className="text-center py-1.5 text-muted-foreground tabular-nums">{item.maxCapacity}</TableCell>
                      <TableCell className="text-center py-1.5">
                        <span className="font-mono text-[11px] text-muted-foreground">{item.machineId}</span>
                      </TableCell>
                      <TableCell className="py-1.5">
                        <div className="flex justify-center gap-1">
                          <button onClick={() => setEditingKey(key)} className="rounded p-1 hover:bg-muted text-muted-foreground hover:text-foreground">
                            <PencilIcon className="size-3.5" />
                          </button>
                          <button onClick={() => handleDeleteProduct(key)} className="rounded p-1 hover:bg-red-100 dark:hover:bg-red-900/40 text-muted-foreground hover:text-red-500">
                            <Trash2Icon className="size-3.5" />
                          </button>
                        </div>
                      </TableCell>
                    </TableRow>
                  )
                })}
              </TableBody>
            </Table>
          </div>
        </>
      )}

      {/* ── MACHINES TAB ── */}
      {tab === "machines" && (
        <>
          <div className="flex items-center justify-between">
            <p className="text-sm text-muted-foreground">{machines.length} machines</p>
            <Button size="sm" className="gap-1.5" onClick={() => { setAddingMachine(true); setEditingMachineId(null) }}>
              <PlusIcon className="size-3.5" />
              Add Machine
            </Button>
          </div>

          <div className="rounded-xl border bg-card overflow-hidden text-xs">
            <Table className="text-xs">
              <TableHeader>
                <TableRow className="hover:bg-transparent">
                  {["Machine ID", "Label / Location", "Actions"].map((h, i) => (
                    <TableHead key={i} className="text-[11px] font-semibold tracking-wide py-2 px-4">{h}</TableHead>
                  ))}
                </TableRow>
              </TableHeader>
              <TableBody>
                {addingMachine && (
                  <MachineEditRow
                    machine={newMachine}
                    onSave={handleAddMachine}
                    onCancel={() => setAddingMachine(false)}
                  />
                )}
                {machines.map((machine) => {
                  if (editingMachineId === machine.value) {
                    return (
                      <MachineEditRow key={machine.value} machine={machine}
                        onSave={handleSaveMachine} onCancel={() => setEditingMachineId(null)} />
                    )
                  }
                  return (
                    <TableRow key={machine.value} className="h-10">
                      <TableCell className="py-1.5 px-4">
                        <span className="font-mono font-bold tracking-wider">{machine.value}</span>
                      </TableCell>
                      <TableCell className="py-1.5 px-4 text-muted-foreground">{machine.label}</TableCell>
                      <TableCell className="py-1.5 px-4">
                        <div className="flex gap-1">
                          <button onClick={() => setEditingMachineId(machine.value)} className="rounded p-1 hover:bg-muted text-muted-foreground hover:text-foreground">
                            <PencilIcon className="size-3.5" />
                          </button>
                          <button onClick={() => handleDeleteMachine(machine.value)} className="rounded p-1 hover:bg-red-100 dark:hover:bg-red-900/40 text-muted-foreground hover:text-red-500">
                            <Trash2Icon className="size-3.5" />
                          </button>
                        </div>
                      </TableCell>
                    </TableRow>
                  )
                })}
              </TableBody>
            </Table>
          </div>
        </>
      )}
    </div>
  )
}
